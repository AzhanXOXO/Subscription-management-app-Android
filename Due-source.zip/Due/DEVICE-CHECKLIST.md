# Due: Android device checks

Use a disposable test subscription and verify these checks on the phone before relying on reminders. These checks have not been executed in this workspace because no Android device or emulator was connected.

- Install and launch on Android 8+; confirm the interface stays clear of status/navigation bars and the keyboard.
- Allow notifications, enable precise reminders, and send a test. Confirm sound and vibration with the app in the background and with the screen locked.
- Deny notifications: reminder health should show the missing permission. Grant later and verify pending reminders are rescheduled.
- Deny precise timing: verify the app remains usable and reports flexible delivery, without crashing.
- Create a real test subscription with a reminder time a few minutes ahead. Close the app normally; verify delivery without keeping the screen open.
- Snooze from the notification; verify it disappears and returns after the snooze time.
- Keep from the notification; verify the decision appears in the app and the notification is cleared.
- Cancel and delete test subscriptions in the app; verify their notifications and future alarms stop.
- Reboot after scheduling a future reminder; verify it is restored. Test a time-zone change as well.
- Review a renewal due today; tomorrow it should move to the next correct billing date, preserving month-end anchors.
- Leave a reminder unreviewed; verify the next day's follow-up and that daily follow-ups stop after the renewal date.
- Export a backup, then restore it after confirmation. Verify subscriptions, currency, preferences, and history. Reject an invalid backup.
- Open a provider link; verify it opens externally and returns safely to Due.
- Test large text, TalkBack, dark mode, rotation, and a small phone screen.
- Force-stop the app, then reopen it. Confirm pending reminders are scheduled again.

Phone model: __________  Android version: __________  Date: __________
Results and issues: _________________________________________________
