import app.due.subscriptions.ScheduleMath;
import java.time.*;
public class ScheduleMathTest {
    static int checks=0;
    static void eq(Object actual,Object expected){checks++;if(!actual.equals(expected))throw new AssertionError(actual+" != "+expected);}
    public static void main(String[] args){
        ZoneId karachi=ZoneId.of("Asia/Karachi");
        eq(ScheduleMath.nextDate(LocalDate.parse("2026-01-31"),"monthly",30,31,1).toString(),"2026-02-28");
        eq(ScheduleMath.nextDate(LocalDate.parse("2026-02-28"),"monthly",30,31,1).toString(),"2026-03-31");
        eq(ScheduleMath.nextDate(LocalDate.parse("2028-01-31"),"monthly",30,31,1).toString(),"2028-02-29");
        eq(ScheduleMath.nextDate(LocalDate.parse("2027-02-28"),"yearly",30,29,2).toString(),"2028-02-29");
        eq(ScheduleMath.nextDate(LocalDate.parse("2026-12-29"),"weekly",30,29,12).toString(),"2027-01-05");
        eq(ScheduleMath.nextDate(LocalDate.parse("2026-01-31"),"custom",45,31,1).toString(),"2026-03-17");
        long first=ScheduleMath.firstTrigger("2026-09-26",2,"09:00",karachi);
        eq(Instant.ofEpochMilli(first).atZone(karachi).toString(),"2026-09-24T09:00+05:00[Asia/Karachi]");
        eq(ScheduleMath.nextTrigger("2026-09-26",2,"09:00",0,0,true,false,karachi),first);
        eq(ScheduleMath.nextTrigger("2026-09-26",2,"09:00",first,first+3600000,true,false,karachi),first+3600000);
        eq(ScheduleMath.nextTrigger("2026-09-26",2,"09:00",first,0,false,false,karachi),Long.MAX_VALUE);
        eq(ScheduleMath.nextTrigger("2026-09-26",2,"09:00",first,0,true,false,karachi),first+86400000);
        eq(ScheduleMath.nextTrigger("2026-09-26",2,"09:00",first+2*86400000,0,true,false,karachi),Long.MAX_VALUE);
        long reviewed=ScheduleMath.nextTrigger("2026-09-26",2,"09:00",0,0,true,true,karachi);
        eq(Instant.ofEpochMilli(reviewed).atZone(karachi).toLocalDate().toString(),"2026-09-27");
        ZoneId ny=ZoneId.of("America/New_York");
        long before=ScheduleMath.firstTrigger("2026-03-09",2,"09:00",ny);
        long after=ScheduleMath.nextTrigger("2026-03-09",2,"09:00",before,0,true,false,ny);
        eq(after-before,23*3600000L);
        eq(Instant.ofEpochMilli(after).atZone(ny).getHour(),9);
        System.out.println("PASS: "+checks+" native scheduling checks (including daylight saving time)");
    }
}
