param(
  [string]$JavaHome = $env:JAVA_HOME,
  [string]$AndroidJar,
  [string]$BuildTools,
  [string]$Output = (Join-Path $PSScriptRoot 'Due-1.0.apk'),
  [string]$BuildDirectory = (Join-Path $PSScriptRoot '.build'),
  [string]$KeyStore = (Join-Path $PSScriptRoot '.local-signing.p12')
)
$ErrorActionPreference='Stop'
if(!$JavaHome -or !(Test-Path (Join-Path $JavaHome 'bin\javac.exe'))){throw 'Pass -JavaHome with a JDK 17 folder.'}
if(!(Test-Path $AndroidJar) -or !(Test-Path $BuildTools)){throw 'Pass -AndroidJar and -BuildTools from Android SDK 36.'}
$env:JAVA_HOME=$JavaHome
$env:Path=(Join-Path $JavaHome 'bin')+';'+$env:Path
$src=Join-Path $PSScriptRoot 'android\app\src\main'
$build=$BuildDirectory
New-Item -ItemType Directory -Force $build,(Join-Path $build 'gen'),(Join-Path $build 'classes'),(Join-Path $build 'dex') | Out-Null
$manifest=Join-Path $build 'AndroidManifest.xml'
(Get-Content -LiteralPath (Join-Path $src 'AndroidManifest.xml') -Raw).Replace('<manifest ', '<manifest package="app.due.subscriptions" ') | Set-Content -Encoding utf8 $manifest
function Run([string]$Executable,[string[]]$Arguments){ & $Executable @Arguments; if($LASTEXITCODE -ne 0){throw "Build step failed: $Executable"} }
Run (Join-Path $BuildTools 'aapt2.exe') @('compile','--dir',(Join-Path $src 'res'),'-o',(Join-Path $build 'res.zip'))
Run (Join-Path $BuildTools 'aapt2.exe') @('link','-o',(Join-Path $build 'unsigned.apk'),'-I',$AndroidJar,'--manifest',$manifest,'--java',(Join-Path $build 'gen'),'-A',(Join-Path $src 'assets'),'--min-sdk-version','26','--target-sdk-version','36',(Join-Path $build 'res.zip'))
$sources=@(Get-ChildItem (Join-Path $src 'java'),(Join-Path $build 'gen') -Recurse -Filter '*.java' | ForEach-Object FullName)
Run (Join-Path $JavaHome 'bin\javac.exe') (@('-encoding','UTF-8','-source','8','-target','8','-classpath',$AndroidJar,'-d',(Join-Path $build 'classes'))+$sources)
Run (Join-Path $JavaHome 'bin\jar.exe') @('cf',(Join-Path $build 'classes.jar'),'-C',(Join-Path $build 'classes'),'.')
Run (Join-Path $BuildTools 'd8.bat') @('--lib',$AndroidJar,'--min-api','26','--output',(Join-Path $build 'dex'),(Join-Path $build 'classes.jar'))
Run (Join-Path $JavaHome 'bin\jar.exe') @('uf',(Join-Path $build 'unsigned.apk'),'-C',(Join-Path $build 'dex'),'classes.dex')
Run (Join-Path $BuildTools 'zipalign.exe') @('-f','4',(Join-Path $build 'unsigned.apk'),(Join-Path $build 'aligned.apk'))
if(!(Test-Path $KeyStore)){
  Run (Join-Path $JavaHome 'bin\keytool.exe') @('-genkeypair','-keystore',$KeyStore,'-storepass','android','-keypass','android','-alias','due-development','-keyalg','RSA','-keysize','2048','-validity','10000','-dname','CN=Due Development, O=Local Development, C=US')
}
Run (Join-Path $BuildTools 'apksigner.bat') @('sign','--v4-signing-enabled','false','--ks',$KeyStore,'--ks-pass','pass:android','--key-pass','pass:android','--ks-key-alias','due-development','--out',$Output,(Join-Path $build 'aligned.apk'))
Run (Join-Path $BuildTools 'apksigner.bat') @('verify','--verbose',$Output)
Write-Output "Built: $Output"
