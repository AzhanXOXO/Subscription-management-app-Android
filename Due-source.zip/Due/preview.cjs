const http=require('http'),fs=require('fs'),path=require('path');
const root=path.join(__dirname,'android/app/src/main/assets');
const types={'.html':'text/html','.js':'application/javascript','.css':'text/css'};
http.createServer((req,res)=>{
  let name=new URL(req.url,'http://localhost').pathname;
  if(name==='/phone') {res.writeHead(200,{'Content-Type':'text/html'});return res.end('<!doctype html><meta charset="utf-8"><title>Due · Android preview</title><body style="margin:0;background:#e9edf4;display:flex;align-items:center;justify-content:center;min-height:100vh"><iframe title="Due phone preview" src="/" style="width:390px;height:844px;border:0;border-radius:28px;box-shadow:0 20px 80px #14213d25"></iframe>');}
  if(name==='/')name='/index.html';
  const target=path.resolve(root,'.'+decodeURIComponent(name));
  if(!target.startsWith(root+path.sep)){res.writeHead(403);return res.end();}
  fs.readFile(target,(err,data)=>{if(err){res.writeHead(404);res.end();}else{res.writeHead(200,{'Content-Type':types[path.extname(target)]||'application/octet-stream','Cache-Control':'no-store'});res.end(data);}});
}).listen(4173,'127.0.0.1',()=>console.log('Due preview available at http://127.0.0.1:4173/phone'));

