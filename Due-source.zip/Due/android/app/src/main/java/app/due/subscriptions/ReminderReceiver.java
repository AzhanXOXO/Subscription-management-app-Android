package app.due.subscriptions;
import android.content.*;
import org.json.*;
public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent intent){
        String action=intent.getAction();
        if("test".equals(action)){
            try{Reminders.notify(c,new JSONObject().put("id","test").put("name","Due").put("currency","USD").put("amount",0).put("type","paid"),false,true);}catch(JSONException ignored){}
        }else if("keep".equals(action)||"snooze".equals(action)){Reminders.decision(c,intent);}
        else{Reminders.deliver(c);}
    }
}
