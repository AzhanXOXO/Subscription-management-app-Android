package app.due.subscriptions;

import android.content.Context;
import org.json.*;
import java.time.*;
import java.util.*;

public final class Store {
    private Store() {}
    public static synchronized JSONObject load(Context c) {
        String raw=c.getSharedPreferences("due",0).getString("database",null);
        try { return raw==null ? fresh() : new JSONObject(raw); }
        catch(JSONException e) { throw new IllegalStateException("Saved data could not be read. Export or restore a backup before continuing.",e); }
    }
    public static JSONObject fresh() {
        try {return new JSONObject("{\"version\":1,\"settings\":{\"currency\":\"USD\",\"leadDays\":2,\"time\":\"09:00\",\"persistent\":true,\"repeat\":true,\"theme\":\"light\",\"budget\":0,\"onboarded\":false},\"subscriptions\":[],\"history\":[]}");}
        catch(JSONException impossible){throw new IllegalStateException(impossible);}
    }
    public static synchronized void write(Context c,JSONObject db) {
        long revision=c.getSharedPreferences("due",0).getLong("revision",0)+1;
        try{db.put("revision",revision);}catch(JSONException e){throw new IllegalStateException(e);}
        if(!c.getSharedPreferences("due",0).edit().putLong("revision",revision).putString("database",db.toString()).commit()) throw new IllegalStateException("Could not save. Check your phone's available storage.");
    }
    public static void validate(JSONObject db) throws Exception {
        if(db.toString().length()>5_000_000||db.getInt("version")!=1)throw new Exception("Invalid Due backup");
        JSONArray subs=db.getJSONArray("subscriptions");
        if(subs.length()>1000||db.getJSONArray("history").length()>10000)throw new Exception("Too many entries");
        JSONObject prefs=db.getJSONObject("settings");
        currency(prefs.getString("currency")); LocalTime.parse(prefs.getString("time"));
        range(prefs.getInt("leadDays"),0,90); amount(prefs.getDouble("budget"));
        if(!Arrays.asList("light","dark","system").contains(prefs.getString("theme")))throw new Exception("Invalid theme");
        HashSet<String> ids=new HashSet<>();
        for(int i=0;i<subs.length();i++) {
            JSONObject s=subs.getJSONObject(i); String id=s.getString("id");
            if(!id.matches("[a-zA-Z0-9-]{1,80}")||!ids.add(id))throw new Exception("Invalid identifier");
            String name=s.getString("name");if(name.trim().isEmpty()||name.length()>80)throw new Exception("Invalid name");
            LocalDate d=LocalDate.parse(s.getString("due"));range(d.getYear(),2000,2100); LocalTime.parse(s.getString("time"));
            range(s.getInt("leadDays"),0,90);range(s.getInt("intervalDays"),1,3650);range(s.optInt("anchorDay",d.getDayOfMonth()),1,31);range(s.optInt("anchorMonth",d.getMonthValue()),1,12);
            amount(s.getDouble("amount"));currency(s.getString("currency"));
            if(!Arrays.asList("monthly","yearly","weekly","custom").contains(s.getString("cycle"))||!Arrays.asList("active","cancelled").contains(s.getString("status"))||!Arrays.asList("trial","paid").contains(s.getString("type")))throw new Exception("Invalid subscription");
            String url=s.optString("website");if(!url.isEmpty()&&!url.matches("(?i)^https?://.+"))throw new Exception("Invalid provider link");
            if(s.optString("notes").length()>1000||url.length()>2000||s.optString("category").length()>80)throw new Exception("Details are too long");
            if(s.optLong("snoozeUntil",0)<0||s.optLong("lastNotifiedAt",0)<0)throw new Exception("Invalid reminder time");
        }
    }
    private static void range(int n,int min,int max)throws Exception{if(n<min||n>max)throw new Exception("Value out of range");}
    private static void amount(double n)throws Exception{if(!Double.isFinite(n)||n<0||n>1e9)throw new Exception("Invalid amount");}
    private static void currency(String c)throws Exception{if(!Arrays.asList("USD","PKR","EUR","GBP","INR","AED","CAD","AUD","SAR").contains(c))throw new Exception("Invalid currency");}
    public static JSONObject find(JSONObject db,String id)throws JSONException{
        JSONArray a=db.getJSONArray("subscriptions");for(int i=0;i<a.length();i++)if(a.getJSONObject(i).getString("id").equals(id))return a.getJSONObject(i);return null;
    }
    public static boolean normalize(JSONObject db)throws JSONException{
        boolean changed=false;JSONArray a=db.getJSONArray("subscriptions");LocalDate now=LocalDate.now();
        for(int i=0;i<a.length();i++){
            JSONObject s=a.getJSONObject(i);LocalDate due=LocalDate.parse(s.getString("due"));
            if(s.getString("status").equals("active")&&s.optString("reviewedDue").equals(due.toString())&&due.isBefore(now)){
                s.put("due",ScheduleMath.nextDate(due,s.getString("cycle"),s.getInt("intervalDays"),s.optInt("anchorDay",due.getDayOfMonth()),s.optInt("anchorMonth",due.getMonthValue())).toString());
                s.put("type","paid");s.put("reviewedDue","");s.put("lastNotifiedAt",0);s.put("snoozeUntil",0);changed=true;
            }
        }return changed;
    }
}
