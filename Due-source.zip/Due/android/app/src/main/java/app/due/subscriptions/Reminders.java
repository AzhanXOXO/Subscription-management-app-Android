package app.due.subscriptions;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import org.json.*;
import java.time.*;
import java.text.NumberFormat;
import java.util.*;

public final class Reminders {
    public static final String CHANNEL="renewal_reminders_v1";
    private Reminders(){}
    public static void channels(Context c){
        NotificationChannel channel=new NotificationChannel(CHANNEL,"Subscription reminders",NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Trial endings and renewal decisions, with sound and vibration.");
        channel.enableVibration(true);channel.setVibrationPattern(new long[]{0,350,150,350});
        channel.setSound(Settings.System.DEFAULT_NOTIFICATION_URI,new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT).build());
        channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        c.getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }
    public static boolean enabled(Context c){
        NotificationManager nm=c.getSystemService(NotificationManager.class);
        NotificationChannel ch=nm.getNotificationChannel(CHANNEL);
        return nm.areNotificationsEnabled()&&(ch==null||ch.getImportance()!=NotificationManager.IMPORTANCE_NONE);
    }
    public static boolean exact(Context c){return Build.VERSION.SDK_INT<31||c.getSystemService(AlarmManager.class).canScheduleExactAlarms();}
    private static PendingIntent alarm(Context c,String action){return PendingIntent.getBroadcast(c,action.equals("test")?2:1,new Intent(c,ReminderReceiver.class).setAction(action),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    public static void set(Context c,String action,long when){
        AlarmManager am=c.getSystemService(AlarmManager.class);PendingIntent pi=alarm(c,action);when=Math.max(System.currentTimeMillis()+1500,when);
        try{if(exact(c))am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);}
        catch(SecurityException e){am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);}
    }
    public static long next(JSONObject s,JSONObject settings)throws JSONException{
        if(!s.getString("status").equals("active")||s.optBoolean("sample",false))return Long.MAX_VALUE;
        return ScheduleMath.nextTrigger(s.getString("due"),s.getInt("leadDays"),s.getString("time"),s.optLong("lastNotifiedAt",0),s.optLong("snoozeUntil",0),settings.optBoolean("repeat",true),s.optString("reviewedDue").equals(s.getString("due")),ZoneId.systemDefault());
    }
    public static synchronized void schedule(Context c){
        channels(c);c.getSystemService(AlarmManager.class).cancel(alarm(c,"due"));
        try{
            JSONObject db=Store.load(c);if(Store.normalize(db))Store.write(c,db);
            JSONArray subs=db.getJSONArray("subscriptions");long next=Long.MAX_VALUE;
            for(int i=0;i<subs.length();i++){
                JSONObject s=subs.getJSONObject(i);
                if(!s.getString("status").equals("active")||s.optString("reviewedDue").equals(s.getString("due"))||s.optLong("snoozeUntil",0)>System.currentTimeMillis())clear(c,s.getString("id"));
                next=Math.min(next,next(s,db.getJSONObject("settings")));
            }
            if(next!=Long.MAX_VALUE&&enabled(c))set(c,"due",next);
        }catch(Exception e){android.util.Log.e("Due","Could not schedule reminders",e);}
    }
    public static void clear(Context c,String id){c.getSystemService(NotificationManager.class).cancel(id,100);}
    private static PendingIntent review(Context c,String id){return PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class).setAction("review").setData(Uri.parse("due://review/"+id)).putExtra("id",id).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    private static PendingIntent action(Context c,String act,JSONObject s)throws JSONException{return PendingIntent.getBroadcast(c,0,new Intent(c,ReminderReceiver.class).setAction(act).setData(Uri.parse("due://"+act+"/"+s.getString("id"))).putExtra("id",s.getString("id")).putExtra("due",s.getString("due")),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    public static boolean notify(Context c,JSONObject s,boolean persistent,boolean test)throws JSONException{
        channels(c);if(!enabled(c))return false;
        String id=s.getString("id"),name=s.getString("name");
        NumberFormat nf=NumberFormat.getCurrencyInstance(Locale.US);nf.setCurrency(Currency.getInstance(s.getString("currency")));
        String amount=nf.format(s.getDouble("amount"));
        String title=test?"Your Due reminders are ready":name+(s.getString("type").equals("trial")?" · trial ending":" · renewal reminder");
        String body=test?"This is how Due will remind you. Review, snooze, or keep a subscription right here.":amount+" on "+s.getString("due")+". Keep it or cancel with the provider before you're charged.";
        Notification.Builder b=new Notification.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_notification).setColor(Color.rgb(49,90,216)).setContentTitle(title).setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setCategory(Notification.CATEGORY_REMINDER).setVisibility(Notification.VISIBILITY_PRIVATE).setOngoing(persistent&&!test).setAutoCancel(!persistent||test).setContentIntent(review(c,test?"":id));
        if(!test){b.addAction(new Notification.Action.Builder(null,"Review",review(c,id)).build());b.addAction(new Notification.Action.Builder(null,"Snooze 1h",action(c,"snooze",s)).build());b.addAction(new Notification.Action.Builder(null,"Keep",action(c,"keep",s)).build());}
        try{c.getSystemService(NotificationManager.class).notify(id,100,b.build());return true;}catch(SecurityException e){return false;}
    }
    public static synchronized void deliver(Context c){
        try{
            JSONObject db=Store.load(c);Store.normalize(db);JSONArray a=db.getJSONArray("subscriptions");JSONObject settings=db.getJSONObject("settings");long now=System.currentTimeMillis();
            for(int i=0;i<a.length();i++){
                JSONObject s=a.getJSONObject(i);
                if(!s.optString("reviewedDue").equals(s.getString("due"))&&next(s,settings)<=now){
                    if(notify(c,s,settings.optBoolean("persistent",true),false)){s.put("lastNotifiedAt",now);s.put("snoozeUntil",0);}
                }
            }Store.write(c,db);
        }catch(Exception e){android.util.Log.e("Due","Could not deliver reminder",e);}
        schedule(c);
    }
    public static synchronized void decision(Context c,Intent intent){
        try{
            JSONObject db=Store.load(c);JSONObject s=Store.find(db,intent.getStringExtra("id"));
            if(s==null||!s.getString("status").equals("active")||!s.getString("due").equals(intent.getStringExtra("due"))||s.optString("reviewedDue").equals(s.getString("due")))return;
            if(intent.getAction().equals("snooze")){s.put("snoozeUntil",System.currentTimeMillis()+3600000);}
            else{s.put("reviewedDue",s.getString("due"));s.put("snoozeUntil",0);db.getJSONArray("history").put(new JSONObject().put("id",UUID.randomUUID().toString()).put("subId",s.getString("id")).put("name",s.getString("name")).put("date",LocalDate.now().toString()).put("action","continued").put("amount",s.getString("amount")).put("currency",s.getString("currency")));}
            Store.write(c,db);clear(c,s.getString("id"));schedule(c);
        }catch(Exception e){android.util.Log.e("Due","Could not update reminder",e);}
    }
}
