package app.due.subscriptions;

import java.time.*;

/** Calendar arithmetic shared by scheduling and device-independent tests. */
public final class ScheduleMath {
    private ScheduleMath() {}
    public static LocalDate nextDate(LocalDate due, String cycle, int days, int anchorDay, int anchorMonth) {
        if (cycle.equals("weekly")) return due.plusDays(7);
        if (cycle.equals("custom")) return due.plusDays(days);
        YearMonth month = cycle.equals("yearly") ? YearMonth.of(due.getYear()+1, anchorMonth) : YearMonth.from(due).plusMonths(1);
        return month.atDay(Math.min(anchorDay, month.lengthOfMonth()));
    }
    public static long firstTrigger(String due, int lead, String time, ZoneId zone) {
        return LocalDate.parse(due).minusDays(lead).atTime(LocalTime.parse(time)).atZone(zone).toInstant().toEpochMilli();
    }
    public static long nextTrigger(String due, int lead, String time, long last, long snooze, boolean repeat, boolean reviewed, ZoneId zone) {
        if(reviewed) return LocalDate.parse(due).plusDays(1).atTime(0,1).atZone(zone).toInstant().toEpochMilli();
        if(snooze>0) return snooze;
        if(last==0) return firstTrigger(due,lead,time,zone);
        if(!repeat) return Long.MAX_VALUE;
        long next=Instant.ofEpochMilli(last).atZone(zone).toLocalDate().plusDays(1).atTime(LocalTime.parse(time)).atZone(zone).toInstant().toEpochMilli();
        long end=LocalDate.parse(due).plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli();
        return next<end ? next : Long.MAX_VALUE;
    }
}
