package app.due.subscriptions;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;

public class MainActivity extends Activity {
    private WebView web;
    private String exportData;
    private boolean ready=false;
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        if(Build.VERSION.SDK_INT>=30)getWindow().setDecorFitsSystemWindows(false);
        if(state!=null)exportData=state.getString("exportData");
        Reminders.channels(this);
        web=new WebView(this);web.setBackgroundColor(Color.rgb(247,248,250));
        WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);settings.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new Bridge(),"DueAndroid");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){return true;}
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest req){
                Uri u=req.getUrl();
                if(!"https".equals(u.getScheme())||!"app.due.local".equals(u.getHost()))return new WebResourceResponse("text/plain","utf-8",new ByteArrayInputStream(new byte[0]));
                String path=u.getPath();String file=path==null||path.equals("/")?"index.html":path.substring(1);
                if(!file.matches("(index\\.html|styles\\.css|core\\.js|app\\.js)"))return new WebResourceResponse("text/plain","utf-8",new ByteArrayInputStream(new byte[0]));
                try{return new WebResourceResponse(file.endsWith(".css")?"text/css":file.endsWith(".js")?"application/javascript":"text/html","utf-8",getAssets().open(file));}
                catch(IOException e){return new WebResourceResponse("text/plain","utf-8",new ByteArrayInputStream(new byte[0]));}
            }
            @Override public void onPageFinished(WebView v,String url){ready=true;openFromIntent();}
        });
        web.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());android.graphics.Insets ime=insets.getInsets(WindowInsets.Type.ime());v.setPadding(bars.left,bars.top,bars.right,Math.max(bars.bottom,ime.bottom));}
            return insets;
        });
        setContentView(web);web.loadUrl("https://app.due.local/index.html");
        if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,()->back());
        Reminders.schedule(this);
    }
    private void back(){web.evaluateJavascript("window.handleBack && window.handleBack()",result->{if(!"true".equals(result))finish();});}
    @Override public void onBackPressed(){back();}
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);out.putString("exportData",exportData);}
    @Override protected void onResume(){super.onResume();Reminders.schedule(this);if(web!=null&&ready)web.evaluateJavascript("window.nativeRefresh && window.nativeRefresh()",null);}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(ready)openFromIntent();}
    private void openFromIntent(){String id=getIntent().getStringExtra("id");if(id!=null&&!id.isEmpty()){web.evaluateJavascript("window.openSubscription("+JSONObject.quote(id)+")",null);getIntent().removeExtra("id");}}
    private void message(String text){runOnUiThread(()->web.evaluateJavascript("window.nativeMessage("+JSONObject.quote(text)+")",null));}
    private void openSettings(Intent i){try{startActivity(i);}catch(ActivityNotFoundException e){message("This settings screen is unavailable on your phone.");}}
    public final class Bridge {
        @JavascriptInterface public String load(){return Store.load(MainActivity.this).toString();}
        @JavascriptInterface public String save(String data){
            synchronized(Reminders.class){try{
                JSONObject incoming=new JSONObject(data);Store.validate(incoming);JSONObject previous=Store.load(MainActivity.this);
                if(incoming.optLong("revision",0)!=previous.optLong("revision",0))return "A reminder updated your subscriptions. Your view has refreshed; please try again.";
                JSONArray a=previous.getJSONArray("subscriptions");
                for(int i=0;i<a.length();i++){JSONObject old=a.getJSONObject(i);JSONObject newer=Store.find(incoming,old.getString("id"));if(newer==null||!newer.getString("due").equals(old.getString("due"))||newer.getInt("leadDays")!=old.getInt("leadDays")||!newer.getString("time").equals(old.getString("time")))Reminders.clear(MainActivity.this,old.getString("id"));}
                Store.write(MainActivity.this,incoming);Reminders.schedule(MainActivity.this);return "ok:"+Store.load(MainActivity.this).optLong("revision",0);
            }catch(Exception e){return e.getMessage()==null?"Could not save your changes.":e.getMessage();}}
        }
        @JavascriptInterface public String status(){return "{\"notifications\":"+Reminders.enabled(MainActivity.this)+",\"exact\":"+Reminders.exact(MainActivity.this)+"}";}
        @JavascriptInterface public void theme(boolean dark){runOnUiThread(()->{
            web.setBackgroundColor(dark?Color.rgb(16,23,37):Color.rgb(247,248,250));
            if(Build.VERSION.SDK_INT>=30){WindowInsetsController controller=getWindow().getInsetsController();if(controller!=null)controller.setSystemBarsAppearance(dark?0:WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);}
            else web.setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        });}
        @JavascriptInterface public void notifications(){runOnUiThread(()->{
            if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){if(getPreferences(0).getBoolean("asked_notifications",false)&&!shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)){openSettings(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));}
                else {getPreferences(0).edit().putBoolean("asked_notifications",true).apply();requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},20);}}
            else openSettings(new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()).putExtra(Settings.EXTRA_CHANNEL_ID,Reminders.CHANNEL));
        });}
        @JavascriptInterface public void exactAlarms(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=31)openSettings(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));else message("Precise reminders are already available.");});}
        @JavascriptInterface public void testReminder(){Reminders.set(MainActivity.this,"test",System.currentTimeMillis()+10000);}
        @JavascriptInterface public void openLink(String url){runOnUiThread(()->{Uri uri=Uri.parse(url);if(("https".equalsIgnoreCase(uri.getScheme())||"http".equalsIgnoreCase(uri.getScheme()))&&uri.getHost()!=null){try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(ActivityNotFoundException e){message("No browser is available to open this link.");}}});}
        @JavascriptInterface public void exportBackup(String data){runOnUiThread(()->{exportData=data;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"due-backup-"+LocalDate.now()+".json");try{startActivityForResult(i,30);}catch(ActivityNotFoundException e){message("No file picker is available.");}});}
        @JavascriptInterface public void importBackup(){runOnUiThread(()->{try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE),31);}catch(ActivityNotFoundException e){message("No file picker is available.");}});}
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);Reminders.schedule(this);if(ready)web.evaluateJavascript("window.nativeRefresh()",null);if(request==20&&(results.length==0||results[0]!=PackageManager.PERMISSION_GRANTED))message("Notifications are off. Enable them in Settings whenever you're ready.");}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;
        try{
            if(request==30&&exportData!=null){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){if(out==null)throw new IOException();out.write(exportData.getBytes(StandardCharsets.UTF_8));}exportData=null;message("Backup saved.");}
            if(request==31){try(InputStream in=getContentResolver().openInputStream(data.getData());ByteArrayOutputStream out=new ByteArrayOutputStream()){
                if(in==null)throw new IOException();byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1){out.write(buffer,0,n);if(out.size()>5_000_000)throw new IOException("Backup is too large");}
                String raw=out.toString("UTF-8");Store.validate(new JSONObject(raw));
                web.evaluateJavascript("window.receiveBackup("+JSONObject.quote(raw)+")",null);
            }}
        }catch(Exception e){message("Could not read or write that backup. Choose a valid Due JSON backup.");}
    }
    @Override protected void onDestroy(){if(web!=null){web.removeJavascriptInterface("DueAndroid");web.destroy();}super.onDestroy();}
}
