(function(root) {
  'use strict';
  const today = () => localDate(new Date());
  function localDate(d) { return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
  function parse(s) { const [y,m,d]=s.split('-').map(Number); return new Date(y,m-1,d,12); }
  function addDays(s,n) { const d=parse(s); d.setDate(d.getDate()+n); return localDate(d); }
  function days(s,base=today()) { return Math.round((parse(s)-parse(base))/86400000); }
  function nextDate(s) {
    const d=parse(s.due);
    if(s.cycle==='weekly'||s.cycle==='custom') return addDays(s.due,s.cycle==='weekly'?7:s.intervalDays);
    let y=d.getFullYear(),m=d.getMonth()+(s.cycle==='yearly'?12:1);
    if(s.cycle==='yearly') m=(s.anchorMonth||d.getMonth()+1)-1+12;
    y+=Math.floor(m/12); m%=12;
    return localDate(new Date(y,m,Math.min(s.anchorDay||d.getDate(),new Date(y,m+1,0).getDate()),12));
  }
  function normalize(db,base=today()) {
    for(const s of db.subscriptions) {
      if(s.status==='active'&&s.reviewedDue===s.due&&s.due<base) {
        s.due=nextDate(s); s.type='paid'; s.reviewedDue=''; s.lastNotifiedAt=0; s.snoozeUntil=0;
      }
    }
    return db;
  }
  function monthly(s) { return Number(s.amount)*(s.cycle==='yearly'?1/12:s.cycle==='weekly'?52/12:s.cycle==='custom'?365.25/s.intervalDays/12:1); }
  function money(amount,currency='USD') { return new Intl.NumberFormat('en',{style:'currency',currency,maximumFractionDigits:2}).format(amount); }
  function dueLabel(s) { const n=days(s.due); return n<0?`${Math.abs(n)}d overdue`:n===0?'Today':n===1?'Tomorrow':`In ${n} days`; }
  function reminderAt(s) { return new Date(`${addDays(s.due,-s.leadDays)}T${s.time}:00`).getTime(); }
  function needsReview(s,now=Date.now()) { return s.status==='active'&&s.reviewedDue!==s.due&&reminderAt(s)<=now; }
  function fresh() {return {version:1,settings:{currency:'USD',leadDays:2,time:'09:00',persistent:true,repeat:true,theme:'light',budget:0,onboarded:false},subscriptions:[],history:[]};}
  function validate(db) {
    if(!db||db.version!==1||!db.settings||!Array.isArray(db.subscriptions)||!Array.isArray(db.history)||db.subscriptions.length>1000||db.history.length>10000)throw Error('This is not a valid Due backup.');
    const ids=new Set();
    for(const h of db.history) {
      if(!h || typeof h.name!=='string' || h.name.length>80 || !['continued','cancelled'].includes(h.action) || typeof h.date!=='string' || !/^\d{4}-\d{2}-\d{2}$/.test(h.date))throw Error('Invalid decision history.');
    }
    for(const s of db.subscriptions) {
      if(typeof s.id!=='string'||!/^[a-zA-Z0-9-]{1,80}$/.test(s.id)||ids.has(s.id))throw Error('Invalid subscription identifier.'); ids.add(s.id);
      if(typeof s.name!=='string'||!s.name.trim()||s.name.length>80||!Number.isFinite(Number(s.amount))||Number(s.amount)<0||Number(s.amount)>1e9||!['USD','PKR','EUR','GBP','INR','AED','CAD','AUD','SAR'].includes(s.currency))throw Error('Invalid subscription details.');
      if(!/^\d{4}-\d{2}-\d{2}$/.test(s.due)||localDate(parse(s.due))!==s.due||s.due<'2000-01-01'||s.due>'2100-12-31')throw Error('Invalid renewal date.');
      if(!['monthly','yearly','weekly','custom'].includes(s.cycle)||!['active','cancelled'].includes(s.status)||!['trial','paid'].includes(s.type)||!Number.isInteger(s.leadDays)||s.leadDays<0||s.leadDays>90||!/^([01]\d|2[0-3]):[0-5]\d$/.test(s.time)||!Number.isInteger(s.intervalDays)||s.intervalDays<1||s.intervalDays>3650)throw Error('Invalid reminder settings.');
      if((s.notes!==undefined&&(typeof s.notes!=='string'||s.notes.length>1000)) || (s.category!==undefined&&(typeof s.category!=='string'||s.category.length>80)) || (s.website!==undefined&&(typeof s.website!=='string'||s.website.length>2000)))throw Error('Invalid subscription notes or link.');
      for(const [field,max] of [['anchorDay',31],['anchorMonth',12]])if(s[field]!==undefined&&(!Number.isInteger(s[field])||s[field]<1||s[field]>max))throw Error('Invalid billing anchor.');
      for(const field of ['lastNotifiedAt','snoozeUntil'])if(s[field]!==undefined&&(!Number.isFinite(s[field])||s[field]<0))throw Error('Invalid reminder timestamp.');
      if(s.reviewedDue && s.reviewedDue!==s.due)throw Error('Invalid renewal review.');
      if(s.website && !/^https?:\/\//i.test(s.website))throw Error('Use an http or https provider link.');
    }
    if(!['USD','PKR','EUR','GBP','INR','AED','CAD','AUD','SAR'].includes(db.settings.currency)||!['light','dark','system'].includes(db.settings.theme)||!Number.isInteger(db.settings.leadDays)||db.settings.leadDays<0||db.settings.leadDays>90||!/^([01]\d|2[0-3]):[0-5]\d$/.test(db.settings.time)||!Number.isFinite(Number(db.settings.budget))||Number(db.settings.budget)<0)throw Error('Invalid app settings.');
    return db;
  }
  const api={today,localDate,parse,addDays,days,nextDate,normalize,monthly,money,dueLabel,reminderAt,needsReview,fresh,validate};
  if(typeof module!=='undefined')module.exports=api;else root.DueCore=api;
})(typeof window!=='undefined'?window:globalThis);
